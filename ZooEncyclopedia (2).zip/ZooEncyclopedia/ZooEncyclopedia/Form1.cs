﻿//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Windows.Forms;
//using TUIO;

//namespace ZooEncyclopedia
//{
//    public partial class Form1 : Form, TuioListener
//    {
//        private List<Animal> animals;
//        private Animal draggedAnimal;
//        private TuioClient tuioClient;
//        private string feedbackMessage; 
//        private Brush feedbackBrush; 
//        private Timer feedbackTimer; 
//        private int messageDuration = 2000; 
//        private bool allAnimalsCorrect = false; 
//        private bool isGameStarted = false; 
//        private int loginMarkerId = 10; 
//        private string finalMessage;
//        private Timer loginFeedbackTimer; 

//        public Form1()
//        {
//            InitializeComponent();
//            DoubleBuffered = true; 
//            InitializeAnimals();
//            StartTUIOClient();
//            InitializeInstructions();
//            InitializeFeedback();
//            InitializeLoginFeedback(); 
//            this.BackgroundImage = Image.FromFile("zoo3.jpg");
//            this.BackgroundImageLayout = ImageLayout.Stretch;
//            this.Text = "Zoo Encyclopedia Game";
//            this.Size = new Size(800, 600);
//        }

//        private void InitializeAnimals()
//        {
//            animals = new List<Animal>
//            {
//                new Animal
//                {
//                    MarkerId = 1,
//                    Name = "Lion",
//                    Position = new Point(50, 400), 
//                    HousePosition = new Point(600, 50), 
//                    AnimalImage = LoadImage("lion.jpg"),
//                    HouseImage = LoadImage("lion den.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 2,
//                    Name = "Monkey",
//                    Position = new Point(50, 250),
//                    HousePosition = new Point(600, 250),
//                    AnimalImage = LoadImage("monky.jpg"),
//                    HouseImage = LoadImage("monky tree2.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 3,
//                    Name = "Polar Bear",
//                    Position = new Point(50, 100),
//                    HousePosition = new Point(600, 400),
//                    AnimalImage = LoadImage("polar bears.jpg"),
//                    HouseImage = LoadImage("polar bear den.png"),
//                },
//            };
//        }

//        private Image LoadImage(string path)
//        {
//            try
//            {
//                return Image.FromFile(path);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
//                return null; 
//            }
//        }

//        private void StartTUIOClient()
//        {
//            tuioClient = new TuioClient(3333);
//            tuioClient.addTuioListener(this);
//            tuioClient.connect();
//        }

//        public void addTuioObject(TuioObject to)
//        {
//            if (!isGameStarted)
//            {

//                if (to.SymbolID == loginMarkerId)
//                {
//                    isGameStarted = true; 
//                    feedbackMessage = "Login Successful! Game Started!";
//                    feedbackBrush = Brushes.Green;
//                    feedbackTimer.Start(); 
//                    loginFeedbackTimer.Start(); 
//                    Invalidate();
//                }
//                else
//                {

//                    feedbackMessage = "Incorrect Marker! Please Try Again.";
//                    feedbackBrush = Brushes.Red;
//                    feedbackTimer.Start(); // Display the error message
//                    loginFeedbackTimer.Start(); // Start timer to clear message
//                    Invalidate();
//                }
//                return;
//            }

//            foreach (var animal in animals)
//            {
//                if (animal.MarkerId == to.SymbolID)
//                {
//                    int scaledX = (int)(to.X * this.ClientSize.Width);
//                    int scaledY = (int)(to.Y * this.ClientSize.Height);
//                    animal.Position = new Point(scaledX, scaledY);
//                    draggedAnimal = animal; 
//                    break;
//                }
//            }
//            Invalidate();
//        }

//        public void updateTuioObject(TuioObject to)
//        {
//            if (!isGameStarted) return;

//            if (draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
//            {
//                int scaledX = (int)(to.X * this.ClientSize.Width);
//                int scaledY = (int)(to.Y * this.ClientSize.Height);
//                draggedAnimal.Position = new Point(scaledX, scaledY);
//                Invalidate();
//            }
//        }

//        public void removeTuioObject(TuioObject to)
//        {
//            if (!isGameStarted) return;

//            if (draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
//            {
//                CheckAnimalPlacement(draggedAnimal);
//                draggedAnimal = null; 
//            }
//        }

//        public void addTuioBlob(TuioBlob tb) { }
//        public void updateTuioBlob(TuioBlob tb) { }
//        public void removeTuioBlob(TuioBlob tb) { }
//        public void addTuioCursor(TuioCursor tc) { }
//        public void updateTuioCursor(TuioCursor tc) { }
//        public void removeTuioCursor(TuioCursor tc) { }
//        public void refresh(TuioTime time) { }

//        private void CheckCompletion()
//        {
//            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
//            {
//                allAnimalsCorrect = true; 
//                finalMessage = "Great job, all is correct!"; 
//                Invalidate(); 
//            }
//        }

//        protected override void OnPaint(PaintEventArgs e)
//        {
//            base.OnPaint(e);

//            if (!isGameStarted)
//            {
//                e.Graphics.DrawString("Please place the login marker to start the game.", new Font("Arial", 24, FontStyle.Bold), Brushes.Black, this.ClientSize.Width / 2 - 370, this.ClientSize.Height / 2 - 50);
//                return;
//            }

//            DrawAnimals(e.Graphics);
//            DrawHouses(e.Graphics); 
//            DrawFeedback(e.Graphics); 

//            if (allAnimalsCorrect)
//            {
//                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
//            }
//        }

//        private void DrawAnimals(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.AnimalImage != null)
//                {
//                    g.DrawImage(animal.AnimalImage, animal.Position.X, animal.Position.Y, 100, 100);
//                    g.DrawString(animal.Name, this.Font, Brushes.Black, animal.Position.X, animal.Position.Y - 15);
//                }
//            }
//        }

//        private void DrawHouses(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.HouseImage != null)
//                {
//                    g.DrawImage(animal.HouseImage, animal.HousePosition.X, animal.HousePosition.Y, 100, 100);
//                }
//            }
//        }

//        private void CheckAnimalPlacement(Animal animal)
//        {
//            if (IsAnimalInHouse(animal))
//            {
//                animal.Position = animal.HousePosition; 
//                animal.IsInCorrectHouse = true; 
//                SetFeedback("Correct", Brushes.Green); 
//            }
//            else
//            {
//                animal.IsInCorrectHouse = false; 
//                SetFeedback("Wrong", Brushes.Red); 
//            }
//            Invalidate(); 
//            CheckCompletion(); 
//        }

//        private bool IsAnimalInHouse(Animal animal)
//        {
//            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
//        }

//        private void InitializeInstructions()
//        {
//            Label instructionsLabel = new Label
//            {
//                Text = "Drag the animals to their habitat!",
//                Location = new Point(20, 20),
//                Size = new Size(300, 30),
//                Font = new Font("Arial", 12, FontStyle.Bold),
//                ForeColor = Color.Black,
//                BackColor = Color.Transparent
//            };
//            this.Controls.Add(instructionsLabel);
//        }

//        private void InitializeFeedback()
//        {
//            feedbackMessage = string.Empty; 
//            feedbackBrush = Brushes.Transparent; 
//            feedbackTimer = new Timer { Interval = messageDuration };
//            feedbackTimer.Tick += (s, e) =>
//            {
//                feedbackMessage = string.Empty;
//                feedbackBrush = Brushes.Transparent;
//                feedbackTimer.Stop();
//                Invalidate(); 
//            };
//        }

//        private void InitializeLoginFeedback()
//        {
//            loginFeedbackTimer = new Timer { Interval = messageDuration };
//            loginFeedbackTimer.Tick += (s, e) =>
//            {
//                feedbackMessage = string.Empty;
//                feedbackBrush = Brushes.Transparent;
//                loginFeedbackTimer.Stop();
//                Invalidate(); 
//            };
//        }

//        private void DrawFeedback(Graphics g)
//        {
//            if (!string.IsNullOrEmpty(feedbackMessage))
//            {
//                g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, 100, 50);
//            }
//        }

//        private void SetFeedback(string message, Brush color)
//        {
//            feedbackMessage = message;
//            feedbackBrush = color;
//            feedbackTimer.Start(); 
//        }
//    }

//    public class Animal
//    {
//        public int MarkerId { get; set; }
//        public string Name { get; set; }
//        public Point Position { get; set; }
//        public Point HousePosition { get; set; }
//        public Image AnimalImage { get; set; }
//        public Image HouseImage { get; set; }
//        public bool IsInCorrectHouse { get; set; }
//    }
//}





//phase2



//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Windows.Forms;
//using TUIO;

//namespace ZooEncyclopedia
//{
//    public partial class Form1 : Form, TuioListener
//    {
//        private List<Animal> animals;
//        private Animal draggedAnimal;
//        private TuioClient tuioClient;
//        private string feedbackMessage;
//        private Brush feedbackBrush;
//        private Timer feedbackTimer;
//        private int messageDuration = 2000;
//        private bool allAnimalsCorrect = false;
//        private bool isGameStarted = false;
//        private int loginMarkerId = 10;
//        private int selectedAnimalIndex = -1; // No animal selected initially
//        private string finalMessage;
//        private Timer loginFeedbackTimer;
//        private float angle = 0; // Angle for rotating the circular menu
//        private float angleIncrement = 5f; // Angle increment for rotation
//        private const int menuRadius = 200; // Radius for circular menu

//        public Form1()
//        {
//            InitializeComponent();
//            DoubleBuffered = true;
//            InitializeAnimals();
//            StartTUIOClient();
//            InitializeInstructions();
//            InitializeFeedback();
//            InitializeLoginFeedback();
//            this.BackgroundImage = Image.FromFile("zoo3.jpg");
//            this.BackgroundImageLayout = ImageLayout.Stretch;
//            this.Text = "Zoo Encyclopedia Game";
//            this.Size = new Size(800, 600);
//        }

//        private void InitializeAnimals()
//        {
//            animals = new List<Animal>
//            {
//                new Animal
//                {
//                    MarkerId = 1,
//                    Name = "Lion",
//                    Position = new Point(600, 50),
//                    HousePosition = new Point(600, 50),
//                    AnimalImage = LoadImage("lion.jpg"),
//                    HouseImage = LoadImage("lion den.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 2,
//                    Name = "Monkey",
//                    Position = new Point(600, 250),
//                    HousePosition = new Point(600, 250),
//                    AnimalImage = LoadImage("monky.jpg"),
//                    HouseImage = LoadImage("monky tree2.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 3,
//                    Name = "Polar Bear",
//                    Position = new Point(600, 400),
//                    HousePosition = new Point(600, 400),
//                    AnimalImage = LoadImage("polar bears.jpg"),
//                    HouseImage = LoadImage("polar bear den.png"),
//                },
//            };
//        }

//        private Image LoadImage(string path)
//        {
//            try
//            {
//                return Image.FromFile(path);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
//                return null;
//            }
//        }

//        private void StartTUIOClient()
//        {
//            tuioClient = new TuioClient(3333);
//            tuioClient.addTuioListener(this);
//            tuioClient.connect();
//        }

//        public void addTuioObject(TuioObject to)
//        {
//            // Rotate with marker 11
//            if (!isGameStarted && to.SymbolID == 11)
//            {
//                // Rotate the menu
//                angle += angleIncrement;
//                if (angle >= 360) angle = 0;
//                Invalidate();
//                return;
//            }

//            // Select with marker 12
//            if (!isGameStarted && to.SymbolID == 12)
//            {
//                // Set selected animal index based on angle
//                selectedAnimalIndex = (int)((angle / 360) * animals.Count) % animals.Count;
//                feedbackMessage = $"{animals[selectedAnimalIndex].Name} selected!";
//                feedbackBrush = Brushes.Green;
//                feedbackTimer.Start();
//                isGameStarted = true; // Start the game after selection
//                Invalidate();
//                return;
//            }

//            if (isGameStarted)
//            {
//                foreach (var animal in animals)
//                {
//                    if (animal.MarkerId == to.SymbolID)
//                    {
//                        int scaledX = (int)(to.X * this.ClientSize.Width);
//                        int scaledY = (int)(to.Y * this.ClientSize.Height);
//                        animal.Position = new Point(scaledX, scaledY);
//                        draggedAnimal = animal;
//                        break;
//                    }
//                }
//                Invalidate();
//            }
//        }

//        public void updateTuioObject(TuioObject to)
//        {
//            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
//            {
//                int scaledX = (int)(to.X * this.ClientSize.Width);
//                int scaledY = (int)(to.Y * this.ClientSize.Height);
//                draggedAnimal.Position = new Point(scaledX, scaledY);
//                Invalidate();
//            }
//        }

//        public void removeTuioObject(TuioObject to)
//        {
//            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
//            {
//                CheckAnimalPlacement(draggedAnimal);
//                draggedAnimal = null;
//            }
//        }

//        public void addTuioBlob(TuioBlob tb) { }
//        public void updateTuioBlob(TuioBlob tb) { }
//        public void removeTuioBlob(TuioBlob tb) { }
//        public void addTuioCursor(TuioCursor tc) { }
//        public void updateTuioCursor(TuioCursor tc) { }
//        public void removeTuioCursor(TuioCursor tc) { }
//        public void refresh(TuioTime time) { }

//        private void CheckCompletion()
//        {
//            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
//            {
//                allAnimalsCorrect = true;
//                finalMessage = "Great job, all is correct!";
//                Invalidate();
//            }
//        }

//        protected override void OnPaint(PaintEventArgs e)
//        {
//            base.OnPaint(e);

//            if (!isGameStarted)
//            {
//                DrawCircularMenu(e.Graphics); // Draw the circular menu
//                return;
//            }

//            DrawAnimals(e.Graphics);
//            DrawHouses(e.Graphics);
//            DrawFeedback(e.Graphics);

//            if (allAnimalsCorrect)
//            {
//                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
//            }
//        }

//        private void DrawCircularMenu(Graphics g)
//        {
//            int centerX = this.ClientSize.Width / 2;
//            int centerY = this.ClientSize.Height / 2;

//            for (int i = 0; i < animals.Count; i++)
//            {
//                float angleRad = (float)((angle + i * (360 / animals.Count)) * (Math.PI / 180));
//                int animalX = centerX + (int)(menuRadius * Math.Cos(angleRad));
//                int animalY = centerY + (int)(menuRadius * Math.Sin(angleRad));

//                // Draw the animal image
//                g.DrawImage(animals[i].AnimalImage, animalX - 50, animalY - 50, 100, 100);
//                g.DrawString(animals[i].Name, this.Font, Brushes.Black, animalX - 25, animalY + 60);

//                // Draw a circle around the selected animal
//                if (selectedAnimalIndex == i)
//                {
//                    using (Pen circlePen = new Pen(Color.Red, 4))
//                    {
//                        g.DrawEllipse(circlePen, animalX - 60, animalY - 60, 120, 120); // Circle radius of 60
//                    }
//                }
//            }
//        }

//        private void DrawAnimals(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.AnimalImage != null)
//                {
//                    g.DrawImage(animal.AnimalImage, animal.Position.X, animal.Position.Y, 100, 100);
//                    g.DrawString(animal.Name, this.Font, Brushes.Black, animal.Position.X, animal.Position.Y - 15);
//                }
//            }
//        }

//        private void DrawHouses(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.HouseImage != null)
//                {
//                    g.DrawImage(animal.HouseImage, animal.HousePosition.X, animal.HousePosition.Y, 100, 100);
//                }
//            }
//        }

//        private void CheckAnimalPlacement(Animal animal)
//        {
//            if (IsAnimalInHouse(animal))
//            {
//                animal.Position = animal.HousePosition;
//                animal.IsInCorrectHouse = true;
//                SetFeedback("Correct", Brushes.Green);
//            }
//            else
//            {
//                animal.IsInCorrectHouse = false;
//                SetFeedback("Wrong", Brushes.Red);
//            }
//            Invalidate();
//            CheckCompletion();
//        }

//        private bool IsAnimalInHouse(Animal animal)
//        {
//            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
//        }

//        private void InitializeInstructions()
//        {
//            Label instructionsLabel = new Label
//            {
//                Text = "Use TUIO markers 11 to hover and 12 to select an animal. Drag the selected animal to its house!",
//                AutoSize = true,
//                Location = new Point(20, 20),
//                Font = new Font("Arial", 12, FontStyle.Bold),
//                BackColor = Color.Transparent,
//            };
//            Controls.Add(instructionsLabel);
//        }

//        private void InitializeFeedback()
//        {
//            feedbackTimer = new Timer { Interval = messageDuration };
//            feedbackTimer.Tick += (sender, e) => { feedbackMessage = string.Empty; feedbackTimer.Stop(); };
//        }

//        private void SetFeedback(string message, Brush brush)
//        {
//            feedbackMessage = message;
//            feedbackBrush = brush;
//            feedbackTimer.Start();
//        }

//        private void DrawFeedback(Graphics g)
//        {
//            if (!string.IsNullOrEmpty(feedbackMessage))
//            {
//                g.DrawString(feedbackMessage, new Font("Arial", 16, FontStyle.Bold), feedbackBrush, this.ClientSize.Width / 2 - 50, this.ClientSize.Height / 2);
//            }
//        }

//        private void InitializeLoginFeedback()
//        {
//            loginFeedbackTimer = new Timer { Interval = messageDuration };
//            loginFeedbackTimer.Tick += (sender, e) => { feedbackMessage = string.Empty; loginFeedbackTimer.Stop(); };
//        }
//    }

//    // Define Animal class
//    public class Animal
//    {
//        public int MarkerId { get; set; }
//        public string Name { get; set; }
//        public Point Position { get; set; }
//        public Point HousePosition { get; set; }
//        public Image AnimalImage { get; set; }
//        public Image HouseImage { get; set; }
//        public bool IsInCorrectHouse { get; set; }
//    }
//}









//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Windows.Forms;
//using TUIO;

//namespace ZooEncyclopedia
//{
//    public partial class Form1 : Form, TuioListener
//    {
//        private List<Animal> animals;
//        private Animal draggedAnimal;
//        private TuioClient tuioClient;
//        private string feedbackMessage;
//        private Brush feedbackBrush;
//        private Timer feedbackTimer;
//        private int messageDuration = 2000;
//        private bool allAnimalsCorrect = false;
//        private bool isGameStarted = false;
//        private int selectedAnimalIndex = -1;
//        private string finalMessage;
//        private float angle = 0;
//        private float angleIncrement = 5f;
//        private const int menuRadius = 200;

//        public Form1()
//        {
//            InitializeComponent();
//            DoubleBuffered = true;
//            InitializeAnimals();
//            InitializeFeedback();
//            StartTUIOClient();
//            InitializeInstructions();
//            InitializeLoginFeedback();
//            this.BackgroundImage = Image.FromFile("zoo3.jpg");
//            this.BackgroundImageLayout = ImageLayout.Stretch;
//            this.Text = "Zoo Encyclopedia Game";
//            this.Size = new Size(800, 600);
//        }

//        private void InitializeInstructions()
//        {
//            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
//            feedbackBrush = Brushes.Blue;
//            feedbackTimer.Start();
//        }

//        private void InitializeLoginFeedback()
//        {

//            feedbackMessage = "Please log in to start the game.";
//            feedbackBrush = Brushes.Gray;
//            feedbackTimer.Start();
//        }

//        private void InitializeAnimals()
//        {
//            animals = new List<Animal>
//            {
//                new Animal
//                {
//                    MarkerId = 1,
//                    Name = "Lion",
//                    Position = new Point(600, 50),
//                    HousePosition = new Point(600, 50),
//                    AnimalImage = LoadImage("lion.jpg"),
//                    HouseImage = LoadImage("lion den.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 2,
//                    Name = "Monkey",
//                    Position = new Point(600, 250),
//                    HousePosition = new Point(600, 250),
//                    AnimalImage = LoadImage("monky.jpg"),
//                    HouseImage = LoadImage("monky tree2.jpg"),
//                },
//                new Animal
//                {
//                    MarkerId = 3,
//                    Name = "Polar Bear",
//                    Position = new Point(600, 400),
//                    HousePosition = new Point(600, 400),
//                    AnimalImage = LoadImage("polar bears.jpg"),
//                    HouseImage = LoadImage("polar bear den.png"),
//                },
//            };
//        }

//        private Image LoadImage(string path)
//        {
//            try
//            {
//                return Image.FromFile(path);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
//                return null;
//            }
//        }

//        private void StartTUIOClient()
//        {
//            tuioClient = new TuioClient(3333);
//            tuioClient.addTuioListener(this);
//            tuioClient.connect();
//        }

//        public void addTuioObject(TuioObject to)
//        {

//            if (!isGameStarted && to.SymbolID == 11)
//            {
//                angle += angleIncrement;
//                if (angle >= 360) angle = 0;
//                Invalidate();
//                return;
//            }


//            if (!isGameStarted && to.SymbolID == 12)
//            {
//                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

//                if (unplacedAnimals.Count > 0)
//                {

//                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
//                    feedbackMessage = $"{unplacedAnimals[selectedAnimalIndex].Name} selected!";
//                    feedbackBrush = Brushes.Green;
//                    feedbackTimer.Start();
//                    isGameStarted = true;
//                    Invalidate();
//                }
//                return;
//            }


//            if (isGameStarted && selectedAnimalIndex != -1)
//            {
//                var selectedAnimal = animals[selectedAnimalIndex];
//                if (selectedAnimal.MarkerId == to.SymbolID)
//                {

//                    int scaledX = (int)(to.X * this.ClientSize.Width);
//                    int scaledY = (int)(to.Y * this.ClientSize.Height);
//                    selectedAnimal.Position = new Point(scaledX, scaledY);
//                    draggedAnimal = selectedAnimal;
//                    Invalidate();
//                }
//            }
//        }

//        public void updateTuioObject(TuioObject to)
//        {
//            if (isGameStarted && selectedAnimalIndex != -1)
//            {
//                var selectedAnimal = animals[selectedAnimalIndex];
//                if (selectedAnimal.MarkerId == to.SymbolID)
//                {
//                    int scaledX = (int)(to.X * this.ClientSize.Width);
//                    int scaledY = (int)(to.Y * this.ClientSize.Height);
//                    selectedAnimal.Position = new Point(scaledX, scaledY);
//                    Invalidate();
//                }
//            }
//        }


//        public void removeTuioObject(TuioObject to)
//        {
//            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
//            {
//                CheckAnimalPlacement(draggedAnimal);
//                draggedAnimal = null;
//            }
//        }

//        public void addTuioBlob(TuioBlob tb) { }
//        public void updateTuioBlob(TuioBlob tb) { }
//        public void removeTuioBlob(TuioBlob tb) { }
//        public void addTuioCursor(TuioCursor tc) { }
//        public void updateTuioCursor(TuioCursor tc) { }
//        public void removeTuioCursor(TuioCursor tc) { }
//        public void refresh(TuioTime time) { }

//        private void CheckAnimalPlacement(Animal animal)
//        {
//            if (IsAnimalInHouse(animal))
//            {
//                animal.Position = animal.HousePosition;
//                animal.IsInCorrectHouse = true;
//                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);


//                isGameStarted = false;
//                selectedAnimalIndex = -1;

//                Invalidate();
//            }
//            else
//            {
//                animal.IsInCorrectHouse = false;
//                SetFeedback("Wrong placement, try again!", Brushes.Red);
//            }

//            CheckCompletion();
//        }

//        private bool IsAnimalInHouse(Animal animal)
//        {
//            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
//        }

//        private void CheckCompletion()
//        {
//            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
//            {
//                allAnimalsCorrect = true;
//                finalMessage = "Great job, all is correct!";
//                Invalidate();
//            }
//        }

//        protected override void OnPaint(PaintEventArgs e)
//        {
//            base.OnPaint(e);

//            if (!isGameStarted)
//            {
//                DrawCircularMenu(e.Graphics);
//                return;
//            }

//            DrawAnimals(e.Graphics);
//            DrawHouses(e.Graphics);
//            DrawFeedback(e.Graphics);


//            if (selectedAnimalIndex != -1)
//            {
//                var selectedAnimal = animals[selectedAnimalIndex];
//                e.Graphics.DrawImage(selectedAnimal.AnimalImage, selectedAnimal.Position.X, selectedAnimal.Position.Y, 100, 100);
//                e.Graphics.DrawString(selectedAnimal.Name, this.Font, Brushes.Black, selectedAnimal.Position.X + 10, selectedAnimal.Position.Y + 110);
//            }

//            if (allAnimalsCorrect)
//            {
//                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
//            }
//        }

//        private void DrawCircularMenu(Graphics g)
//        {
//            if (selectedAnimalIndex != -1)
//            {
//                var selectedAnimal = animals[selectedAnimalIndex];
//                int centerX = this.ClientSize.Width / 2;
//                int centerY = this.ClientSize.Height / 2;

//                g.DrawImage(selectedAnimal.AnimalImage, centerX - 50, centerY - 50, 100, 100);
//                g.DrawString(selectedAnimal.Name, this.Font, Brushes.Black, centerX - 25, centerY + 60);
//                return;
//            }

//            int menuCenterX = this.ClientSize.Width / 2;
//            int menuCenterY = this.ClientSize.Height / 2;

//            var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

//            for (int i = 0; i < unplacedAnimals.Count; i++)
//            {
//                float angleRad = (float)((angle + i * (360 / unplacedAnimals.Count)) * (Math.PI / 180));
//                int animalX = menuCenterX + (int)(menuRadius * Math.Cos(angleRad));
//                int animalY = menuCenterY + (int)(menuRadius * Math.Sin(angleRad));

//                g.DrawImage(unplacedAnimals[i].AnimalImage, animalX - 50, animalY - 50, 100, 100);
//                g.DrawString(unplacedAnimals[i].Name, this.Font, Brushes.Black, animalX - 25, animalY + 60);

//                if (selectedAnimalIndex != -1 && unplacedAnimals[selectedAnimalIndex] == unplacedAnimals[i])
//                {
//                    using (Pen circlePen = new Pen(Color.Red, 4))
//                    {
//                        g.DrawEllipse(circlePen, animalX - 60, animalY - 60, 120, 120);
//                    }
//                }
//            }
//        }

//        private void DrawAnimals(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.AnimalImage != null)
//                {
//                    g.DrawImage(animal.AnimalImage, animal.Position.X, animal.Position.Y, 100, 100);
//                    g.DrawString(animal.Name, this.Font, Brushes.Black, animal.Position.X + 10, animal.Position.Y + 110);
//                }
//            }
//        }

//        private void DrawHouses(Graphics g)
//        {
//            foreach (var animal in animals)
//            {
//                if (animal.HouseImage != null)
//                {
//                    g.DrawImage(animal.HouseImage, animal.HousePosition.X, animal.HousePosition.Y, 100, 100);
//                }
//            }
//        }

//        private void DrawFeedback(Graphics g)
//        {
//            if (feedbackMessage != null)
//            {
//                g.DrawString(feedbackMessage, this.Font, feedbackBrush, 10, this.ClientSize.Height - 30);
//            }
//        }

//        private void SetFeedback(string message, Brush brush)
//        {
//            feedbackMessage = message;
//            feedbackBrush = brush;
//            feedbackTimer.Start();
//        }

//        private void InitializeFeedback()
//        {
//            feedbackTimer = new Timer();
//            feedbackTimer.Interval = messageDuration;
//            feedbackTimer.Tick += (s, e) =>
//            {
//                feedbackMessage = null;
//                feedbackTimer.Stop();
//                Invalidate();
//            };
//        }
//    }

//    public class Animal
//    {
//        public int MarkerId { get; set; }
//        public string Name { get; set; }
//        public Point Position { get; set; }
//        public Point HousePosition { get; set; }
//        public bool IsInCorrectHouse { get; set; }
//        public Image AnimalImage { get; set; }
//        public Image HouseImage { get; set; }
//    }
//}












using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TUIO;

namespace ZooEncyclopedia
{
    public partial class Form1 : Form, TuioListener
    {
        private List<Animal> animals;
        private List<Animal> activeAnimals = new List<Animal>();
        private Animal draggedAnimal;
        private TuioClient tuioClient;
        private string feedbackMessage;
        private Brush feedbackBrush;
        private Timer feedbackTimer;
        private int messageDuration = 2000;
        private bool allAnimalsCorrect = false;
        private bool isGameStarted = false;
        private int selectedAnimalIndex = -1;
        private string finalMessage;
        private float angle = 0;
        private float angleIncrement = 5f;
        private const int menuRadius = 200;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            InitializeAnimals();
            InitializeFeedback(); // Initialize feedback in constructor
            StartTUIOClient();
            InitializeInstructions();
            InitializeLoginFeedback();
            this.Text = "Zoo Encyclopedia Game";
            this.Size = new Size(800, 600);
            SetDefaultBackground(); // Initialize default background
        }

        private void InitializeFeedback()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;

            feedbackTimer = new Timer();
            feedbackTimer.Interval = messageDuration;
            feedbackTimer.Tick += feedbackTimer_Tick;
            feedbackTimer.Start();
        }

        private void InitializeInstructions()
        {
            feedbackMessage = "Welcome to the Zoo Encyclopedia Game! Select an animal from the menu to start.";
            feedbackBrush = Brushes.Blue;
            feedbackTimer.Start();
        }

        private void InitializeLoginFeedback()
        {
            feedbackMessage = "Please log in to start the game.";
            feedbackBrush = Brushes.Gray;
            feedbackTimer.Start();
        }

        private void InitializeAnimals()
        {
            animals = new List<Animal>
            {
                new Animal
                {
                    MarkerId = 1,
                    Name = "Lion",
                    Position = new Point(600, 50),
                    HousePosition = new Point(600, 50),
                    AnimalImage = LoadImage("lion.jpg"),
                    HouseImage = LoadImage("lion den.jpg"),
                    BackgroundImage = LoadImage("1.jpg"),
                },
                new Animal
                {
                    MarkerId = 2,
                    Name = "Monkey",
                    Position = new Point(600, 250),
                    HousePosition = new Point(600, 250),
                    AnimalImage = LoadImage("monky.jpg"),
                    HouseImage = LoadImage("monky tree2.jpg"),
                    BackgroundImage = LoadImage("2.jpg"),
                },
                new Animal
                {
                    MarkerId = 3,
                    Name = "Polar Bear",
                    Position = new Point(600, 400),
                    HousePosition = new Point(600, 400),
                    AnimalImage = LoadImage("polar bears.jpg"),
                    HouseImage = LoadImage("polar bear den.png"),
                    BackgroundImage = LoadImage("3.jpeg"),
                },
            };
        }

        private Image LoadImage(string path)
        {
            try
            {
                return Image.FromFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image '{path}': {ex.Message}");
                return null;
            }
        }

        private void StartTUIOClient()
        {
            tuioClient = new TuioClient(3333);
            tuioClient.addTuioListener(this);
            tuioClient.connect();
        }

        public void addTuioObject(TuioObject to)
        {
            if (!isGameStarted && to.SymbolID == 11) // Rotate menu
            {
                angle += angleIncrement;
                if (angle >= 360) angle = 0;
                Invalidate();
                return;
            }

            if (!isGameStarted && to.SymbolID == 12) // Select animal from menu
            {
                var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);

                if (unplacedAnimals.Count > 0)
                {
                    selectedAnimalIndex = (int)((angle / 360) * unplacedAnimals.Count) % unplacedAnimals.Count;
                    var selectedAnimal = unplacedAnimals[selectedAnimalIndex];

                    UpdateBackgroundImage(selectedAnimal); // Update background on selection

                    if (!activeAnimals.Contains(selectedAnimal))
                    {
                        activeAnimals.Add(selectedAnimal);
                    }

                    feedbackMessage = $"{selectedAnimal.Name} selected!";
                    feedbackBrush = Brushes.Green;
                    feedbackTimer.Start();
                    isGameStarted = true;

                    Invalidate();
                }
                return;
            }

            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = activeAnimals.Last();
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    draggedAnimal = selectedAnimal;
                    Invalidate();
                }
            }
        }

        public void updateTuioObject(TuioObject to)
        {
            if (isGameStarted && selectedAnimalIndex != -1)
            {
                var selectedAnimal = animals[selectedAnimalIndex];
                if (selectedAnimal.MarkerId == to.SymbolID)
                {
                    int scaledX = (int)(to.X * this.ClientSize.Width);
                    int scaledY = (int)(to.Y * this.ClientSize.Height);
                    selectedAnimal.Position = new Point(scaledX, scaledY);
                    Invalidate();
                }
            }
        }

        public void removeTuioObject(TuioObject to)
        {
            if (isGameStarted && draggedAnimal != null && draggedAnimal.MarkerId == to.SymbolID)
            {
                CheckAnimalPlacement(draggedAnimal);
                draggedAnimal = null;
            }
        }

        public void addTuioBlob(TuioBlob tb) { }
        public void updateTuioBlob(TuioBlob tb) { }
        public void removeTuioBlob(TuioBlob tb) { }
        public void addTuioCursor(TuioCursor tc) { }
        public void updateTuioCursor(TuioCursor tc) { }
        public void removeTuioCursor(TuioCursor tc) { }
        public void refresh(TuioTime time) { }

        private void CheckAnimalPlacement(Animal animal)
        {
            if (IsAnimalInHouse(animal))
            {
                animal.Position = animal.HousePosition;
                animal.IsInCorrectHouse = true;
                SetFeedback($"{animal.Name} placed correctly!", Brushes.Green);

                selectedAnimalIndex = -1;
                isGameStarted = false;

                CheckCompletion();
                Invalidate();
            }
            else
            {
                animal.IsInCorrectHouse = false;
                SetFeedback("Wrong placement, try again!", Brushes.Red);
            }
        }

        private bool IsAnimalInHouse(Animal animal)
        {
            return (Math.Abs(animal.Position.X - animal.HousePosition.X) < 50 && Math.Abs(animal.Position.Y - animal.HousePosition.Y) < 50);
        }

        private void CheckCompletion()
        {
            if (animals.TrueForAll(a => a.IsInCorrectHouse) && !allAnimalsCorrect)
            {
                allAnimalsCorrect = true;
                finalMessage = "Great job, all is correct!";
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (!isGameStarted)
            {
                DrawCircularMenu(e.Graphics);
                return;
            }

            DrawAnimals(e.Graphics);
            DrawHouses(e.Graphics);
            DrawFeedback(e.Graphics);

            if (allAnimalsCorrect)
            {
                e.Graphics.DrawString(finalMessage, new Font("Arial", 24, FontStyle.Bold), Brushes.Blue, this.ClientSize.Width / 2 - 200, this.ClientSize.Height / 2 + 150);
            }
        }

        private void DrawCircularMenu(Graphics g)
        {
            int menuCenterX = this.ClientSize.Width / 2;
            int menuCenterY = this.ClientSize.Height / 2;

            var unplacedAnimals = animals.FindAll(a => !a.IsInCorrectHouse);
            int count = unplacedAnimals.Count;

            for (int i = 0; i < count; i++)
            {
                float angleForAnimal = angle + (360f / count) * i;
                int x = menuCenterX + (int)(menuRadius * Math.Cos(angleForAnimal * Math.PI / 180));
                int y = menuCenterY + (int)(menuRadius * Math.Sin(angleForAnimal * Math.PI / 180));

                g.DrawImage(unplacedAnimals[i].AnimalImage, x - 50, y - 50, 100, 100);
            }
        }

        private void DrawAnimals(Graphics g)
        {
            foreach (var animal in activeAnimals)
            {
                g.DrawImage(animal.AnimalImage, animal.Position.X - 50, animal.Position.Y - 50, 100, 100);
            }
        }

        private void DrawHouses(Graphics g)
        {
            foreach (var animal in animals)
            {
                g.DrawImage(animal.HouseImage, animal.HousePosition.X - 50, animal.HousePosition.Y - 50, 100, 100);
            }
        }

        private void DrawFeedback(Graphics g)
        {
            g.DrawString(feedbackMessage, this.Font, feedbackBrush, 10, 10);
        }

        private void UpdateBackgroundImage(Animal animal)
        {
            this.BackgroundImage = animal.BackgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void SetDefaultBackground()
        {
            this.BackgroundImage = LoadImage("zoo3.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void SetFeedback(string message, Brush color)
        {
            feedbackMessage = message;
            feedbackBrush = color;
            feedbackTimer.Start();
        }

        private void feedbackTimer_Tick(object sender, EventArgs e)
        {
            feedbackTimer.Stop();
            feedbackMessage = string.Empty;
            Invalidate();
        }
    }

    public class Animal
    {
        public int MarkerId { get; set; }
        public string Name { get; set; }
        public Point Position { get; set; }
        public Point HousePosition { get; set; }
        public Image AnimalImage { get; set; }
        public Image HouseImage { get; set; }
        public Image BackgroundImage { get; set; }
        public bool IsInCorrectHouse { get; set; } = false;
    }
}