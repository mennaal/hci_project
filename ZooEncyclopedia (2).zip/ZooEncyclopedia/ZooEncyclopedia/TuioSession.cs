﻿//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Windows.Forms;
//using TUIO;

namespace ZooEncyclopedia
{
    public class TuioSession
    {
    }
}