import socket
import threading
import cv2
from ultralytics import YOLO

# Load the YOLOv11 model
model = YOLO("yolo11n.pt")  # Replace with the correct model file path

# Define the target classes for detection
target_classes = ["dog", "cat", "giraffe", "elephant", "sheep", "horse"]

# Open the webcam
cap = cv2.VideoCapture(1)  # 0 is usually the default camera

if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Initialize socket
def socket_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('127.0.0.1', 12345))  # Port 12345 (or any available port)
    server.listen(1)
    print("Waiting for connection...")
    
    # Wait for connection from the C# client
    client_socket, addr = server.accept()
    print(f"Connected to {addr}")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        # Run YOLO model on the current frame
        results = model(frame)

        # Filter detections for target classes
        filtered_detections = []
        for r in results:
            for box in r.boxes:
                cls_id = int(box.cls)
                cls_name = model.names[cls_id]  # Get class name
                if cls_name in target_classes:
                    filtered_detections.append((cls_name, box.xyxy[0]))  # Save the class name and box coordinates

        # Send animal info to C# client
        for animal_type, box in filtered_detections:
            x1, y1, x2, y2 = box.tolist()  # Convert tensor to list and unpack
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)  # Convert to integers
            data = f"{animal_type},{x1},{y1}"  # Send animal type and position (x, y)
            client_socket.sendall(data.encode())  # Send as a string

        # Sleep or wait before sending the next data
        threading.Event().wait(1)  # Adjust time as necessary

# Start the Python socket server in a new thread
def start_server():
    server_thread = threading.Thread(target=socket_server)
    server_thread.daemon = True
    server_thread.start()

if __name__ == "__main__":
    start_server()
    while True:
        pass  # Keep the main thread running
